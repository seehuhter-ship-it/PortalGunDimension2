package eu.codexe.dimensionalportal.world;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public enum DimensionOptions {
    OVERWORLD("minecraft:overworld", Component.literal("Обычный мир")),
    NETHER("minecraft:the_nether", Component.literal("Незер")),
    END("minecraft:the_end", Component.literal("Энд"));

    private final String id;
    private final Component displayName;

    DimensionOptions(String id, Component displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public ResourceKey<Level> level() {
        return ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, new ResourceLocation(id));
    }

    public Component displayName() {
        return displayName;
    }

    public static DimensionOptions byId(ResourceLocation id) {
        for (DimensionOptions option : values()) {
            if (option.level().location().equals(id)) {
                return option;
            }
        }
        return null;
    }
}