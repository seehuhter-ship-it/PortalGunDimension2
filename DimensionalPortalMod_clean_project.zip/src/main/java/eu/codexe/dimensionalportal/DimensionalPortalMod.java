package eu.codexe.dimensionalportal;

import eu.codexe.dimensionalportal.network.ModNetworking;
import eu.codexe.dimensionalportal.registry.ModBlocks;
import eu.codexe.dimensionalportal.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DimensionalPortalMod.MOD_ID)
public class DimensionalPortalMod {
    public static final String MOD_ID = "dimensionalportal";

    public DimensionalPortalMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(modBus);
        ModItems.register(modBus);
        ModNetworking.register();
    }
}