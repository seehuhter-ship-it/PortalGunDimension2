package eu.codexe.dimensionalportal.item;

import eu.codexe.dimensionalportal.client.ClientInit;
import eu.codexe.dimensionalportal.menu.DimensionSelectMenu;
import eu.codexe.dimensionalportal.registry.ModMenuTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class DimensionCannonItem extends Item {
    public DimensionCannonItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, net.minecraft.world.entity.player.Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ServerPlayer serverPlayer = (ServerPlayer) player;
            serverPlayer.openMenu(new SimpleMenuProvider(
                    (id, inventory, p) -> new DimensionSelectMenu(id, inventory),
                    Component.literal("Пушка путешествия")
            ));
        } else {
            ClientInit.openScreen(Component.literal("Пушка путешествия"));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}