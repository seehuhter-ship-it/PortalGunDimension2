package eu.codexe.dimensionalportal.registry;

import eu.codexe.dimensionalportal.DimensionalPortalMod;
import eu.codexe.dimensionalportal.item.DimensionCannonItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DimensionalPortalMod.MOD_ID);

    public static final RegistryObject<Item> DIMENSION_CANNON = ITEMS.register("dimension_cannon",
            () -> new DimensionCannonItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> GREEN_PORTAL_BLOCK_ITEM = ITEMS.register("green_portal_block",
            () -> new BlockItem(ModBlocks.GREEN_PORTAL_BLOCK.get(), new Item.Properties()));

    private ModItems() {
    }

    public static void register(net.minecraftforge.eventbus.api.IEventBus bus) {
        ITEMS.register(bus);
    }
}