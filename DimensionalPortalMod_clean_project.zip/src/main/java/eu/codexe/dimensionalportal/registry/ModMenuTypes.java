package eu.codexe.dimensionalportal.registry;

import eu.codexe.dimensionalportal.DimensionalPortalMod;
import eu.codexe.dimensionalportal.menu.DimensionSelectMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENU_TYPES = DeferredRegister.create(ForgeRegistries.MENU_TYPES, DimensionalPortalMod.MOD_ID);

    public static final RegistryObject<MenuType<DimensionSelectMenu>> DIMENSION_SELECT = MENU_TYPES.register("dimension_select",
            () -> IForgeMenuType.create(DimensionSelectMenu::new));

    private ModMenuTypes() {
    }

    public static void register(net.minecraftforge.eventbus.api.IEventBus bus) {
        MENU_TYPES.register(bus);
    }
}