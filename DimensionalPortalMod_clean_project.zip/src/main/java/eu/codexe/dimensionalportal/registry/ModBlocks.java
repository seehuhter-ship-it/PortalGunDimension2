package eu.codexe.dimensionalportal.registry;

import eu.codexe.dimensionalportal.DimensionalPortalMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, DimensionalPortalMod.MOD_ID);

    public static final RegistryObject<Block> GREEN_PORTAL_BLOCK = BLOCKS.register("green_portal_block",
            () -> new Block(BlockBehaviour.Properties.ofFullCopy(Blocks.NETHER_PORTAL)
                    .lightLevel(state -> 11)
                    .noOcclusion()
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.GLASS)));

    private ModBlocks() {
    }

    public static void register(net.minecraftforge.eventbus.api.IEventBus bus) {
        BLOCKS.register(bus);
    }
}