package eu.codexe.dimensionalportal.menu;

import eu.codexe.dimensionalportal.registry.ModMenuTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;

public class DimensionSelectMenu extends AbstractContainerMenu {
    public DimensionSelectMenu(int id, Inventory inventory) {
        super(ModMenuTypes.DIMENSION_SELECT.get(), id);
    }

    public DimensionSelectMenu(int id, Inventory inventory, FriendlyByteBuf buf) {
        this(id, inventory);
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}