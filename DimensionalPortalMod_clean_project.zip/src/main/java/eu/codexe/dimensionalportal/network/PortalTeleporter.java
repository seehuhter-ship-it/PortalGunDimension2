package eu.codexe.dimensionalportal.network;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.util.ITeleporter;

import java.util.function.Function;

public final class PortalTeleporter {
    private PortalTeleporter() {
    }

    public static void teleportPlayer(ServerPlayer player, ResourceKey<Level> destination) {
        ServerLevel targetLevel = player.server.getLevel(destination);
        if (targetLevel == null) {
            return;
        }

        BlockPos targetPos = targetLevel.getSharedSpawnPos();
        player.changeDimension(targetLevel, new ITeleporter() {
            @Override
            public net.minecraft.world.entity.Entity placeEntity(net.minecraft.world.entity.Entity entity, ServerLevel currentWorld, ServerLevel destWorld, float yaw, Function<Boolean, net.minecraft.world.entity.Entity> repositionEntity) {
                net.minecraft.world.entity.Entity placed = repositionEntity.apply(false);
                placed.teleportTo(targetPos.getX() + 0.5, targetPos.getY() + 1, targetPos.getZ() + 0.5);
                return placed;
            }
        });
    }
}