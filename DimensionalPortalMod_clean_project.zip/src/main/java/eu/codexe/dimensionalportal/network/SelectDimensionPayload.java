package eu.codexe.dimensionalportal.network;

import eu.codexe.dimensionalportal.world.DimensionOptions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record SelectDimensionPayload(String dimensionId) {
    public static void encode(SelectDimensionPayload msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.dimensionId());
    }

    public static SelectDimensionPayload decode(FriendlyByteBuf buf) {
        return new SelectDimensionPayload(buf.readUtf(32767));
    }

    public static void handle(SelectDimensionPayload msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) {
                return;
            }

            DimensionOptions option = DimensionOptions.byId(new ResourceLocation(msg.dimensionId()));
            if (option != null) {
                PortalTeleporter.teleportPlayer(player, option.level());
            }
        });
        context.setPacketHandled(true);
    }
}