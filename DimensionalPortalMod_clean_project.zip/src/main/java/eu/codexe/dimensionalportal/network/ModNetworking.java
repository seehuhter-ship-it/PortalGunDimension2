package eu.codexe.dimensionalportal.network;

import eu.codexe.dimensionalportal.DimensionalPortalMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetworking {
    private static final String PROTOCOL_VERSION = "1";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DimensionalPortalMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    private ModNetworking() {
    }

    public static void register() {
        CHANNEL.messageBuilder(SelectDimensionPayload.class, packetId++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SelectDimensionPayload::encode)
                .decoder(SelectDimensionPayload::decode)
                .consumerMainThread(SelectDimensionPayload::handle)
                .add();
    }

    public static void sendToServer(SelectDimensionPayload payload) {
        CHANNEL.sendToServer(payload);
    }
}