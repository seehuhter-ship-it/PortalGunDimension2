package eu.codexe.dimensionalportal.client.screen;

import eu.codexe.dimensionalportal.network.ModNetworking;
import eu.codexe.dimensionalportal.network.SelectDimensionPayload;
import eu.codexe.dimensionalportal.world.DimensionOptions;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public class DimensionSelectScreen extends Screen {
    private final Component title;

    public DimensionSelectScreen(Component title) {
        super(title);
        this.title = title;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = this.height / 4;

        for (DimensionOptions option : DimensionOptions.values()) {
            this.addRenderableWidget(Button.builder(option.displayName(), button -> {
                ModNetworking.sendToServer(new SelectDimensionPayload(option.level().location().toString()));
                Minecraft.getInstance().setScreen(null);
            }).bounds(centerX - 100, y, 200, 20).build());
            y += 24;
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0x55FF55);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}