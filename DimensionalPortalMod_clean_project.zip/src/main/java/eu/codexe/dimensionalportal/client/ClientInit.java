package eu.codexe.dimensionalportal.client;

import eu.codexe.dimensionalportal.DimensionalPortalMod;
import eu.codexe.dimensionalportal.client.screen.DimensionSelectScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

public final class ClientInit {
    private ClientInit() {
    }

    public static void register() {
        DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> ClientInit::registerClient);
    }

    private static void registerClient() {
        MenuScreens.register(ModMenuTypes.DIMENSION_SELECT.get(), DimensionSelectScreen::new);
    }

    public static void openScreen(net.minecraft.network.chat.Component title) {
        Minecraft.getInstance().setScreen(new DimensionSelectScreen(title));
    }
}