@rem
@rem Gradle Wrapper for Windows
@rem
@echo off
setlocal

set APP_HOME=%~dp0
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v8.8.0/gradle/wrapper/gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
    echo Downloading official Gradle 8.8 wrapper...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='%WRAPPER_URL%'; $o='%WRAPPER_JAR%'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $o"
    if errorlevel 1 exit /b 1
)

"%JAVA_HOME%\bin\java.exe" %JAVA_OPTS% %GRADLE_OPTS% -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
if errorlevel 1 exit /b %errorlevel%
endlocal
